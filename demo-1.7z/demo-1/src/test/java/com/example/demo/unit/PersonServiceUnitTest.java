package com.example.demo.unit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.model.Person;
import com.example.demo.service.PersonService;

@ExtendWith(MockitoExtension.class)
public class PersonServiceUnitTest {

	@InjectMocks
	private PersonService personService;

	@Test
	void getPersonById() {
		String id = "1";

		Person testPerson = new Person();
		testPerson.setId("1"); // customer id
		testPerson.setPhno(123); // customer phno
		testPerson.setName("Steve"); // customer name
		testPerson.setAddress("Vpuram"); // customer Address

		Person resultPerson = personService.getPerson(id);

		assertEquals(testPerson, resultPerson);

	}

}
