package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Hashtable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Person;
import com.example.demo.service.PersonService;

@CrossOrigin
@RestController
@RequestMapping("/person")

public class PersonController {

	@Autowired
	PersonService ps;

//	http://localhost:8080/person/
	@RequestMapping("/")
	public ArrayList<Person> getAll() {
		return ps.getAll();
	}

//	http://localhost:8080/person/1
	@RequestMapping("/{id}")
	public Person getPerson(@PathVariable("id") String id) {
		return ps.getPerson(id);
	}

}
